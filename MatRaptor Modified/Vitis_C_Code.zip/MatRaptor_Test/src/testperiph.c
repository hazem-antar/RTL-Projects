
#include <stdio.h>
#include "xparameters.h"
#include "xil_printf.h"

#include "xgpio.h"
#include "gpio_header.h"

#include "xuartlite.h"
#include "uartlite_header.h"

#define DELAY_VALUE 10


void WriteWordToBRAM(int Offset, int Data, int Bram_index);
int InitializeMatrixInBRAM(int start_index, u32 matrix[4][4], int rows, int cols, int Bram_index);
void ReadMatrixFromC2RFormat(u32 C_BaseAddress, int PE1_Values_loc, int PE2_Values_loc,  u32 resultMatrix[4][4]);
void Print_Matrix_2D(u32 matrix[4][4]);
void delay(int number_of_cycles);
u32 Read_BRAM_Content(int offset, int Bram_index);

// Function prototypes for MatRaptor operation
void WaitForMatRaptorCompletion();

int StartMatRaptor(int Matrix_A_start, int Matrix_B_start, int Matrix_C_start, int PE1_Values_loc, int PE2_Values_loc);

int main ()
{
    // Initialize matrix A in normal 2D array form
    u32 MatrixA[4][4] = {
        {1, 2, 0, 0}, // Row 0
        {3, 0, 0, 0}, // Row 1
        {4, 0, 0, 0}, // Row 2
        {0, 0, 0, 0}  // Row 3
    };

    // Initialize matrix B in normal 2D array form
    u32 MatrixB[4][4] = {
        {5, 0, 0, 0}, // Row 0
        {0, 6, 7, 0}, // Row 1
        {8, 0, 0, 0}, // Row 2
        {9, 0, 0, 0}  // Row 3
    };

    xil_printf("Multiplying the following matrices:\n\r");
    xil_printf("A:\n\r");
    Print_Matrix_2D(MatrixA);
    xil_printf("B:\n\r");
    Print_Matrix_2D(MatrixB);
    
    // Initializing memories with matricies in C2R format
     xil_printf("\nInitializing memories with matricies in C2R format..\n\r");
    int BRAM_Matrix_A = 0, BRAM_Matrix_B = 0, BRAM_Matrix_C = 0;
    for (int i = 1; i<4; i++)
    {
        // Initialize matricies in BRAM (i) in C2R format
        BRAM_Matrix_B =  InitializeMatrixInBRAM(BRAM_Matrix_A, MatrixA, 4, 4, i);
        BRAM_Matrix_C = InitializeMatrixInBRAM(BRAM_Matrix_B, MatrixB, 4, 4, i);
    }
    
    // Validate the content inside BRAM1 as an example
    xil_printf("\nValidating BRAMs contents:\n\r");
    for(int i=0; i < BRAM_Matrix_C; i+=4)
    {
        u32 data = Read_BRAM_Content(i, 1);
        xil_printf("Address: %d, Data: %08x\n\r", i, data);
    }
    
    xil_printf("\nInitiating MatRaptor and Sending Pointers..\n\r");
    int finished = StartMatRaptor(BRAM_Matrix_A, BRAM_Matrix_B, BRAM_Matrix_C, 70*4, 90*4);
    
    if (finished == 0)
    {
        return 0;
    }

    // Initialize 2D array to collect the computed C2R result matrix
    u32 resultMatrix[4][4];

    // Collect the computed C2R result matrix
    xil_printf("\nAssembling the C2R output into 2D array..\n\r");
    ReadMatrixFromC2RFormat(BRAM_Matrix_C, 70*4, 90*4, resultMatrix);

    // Print the computed matrix in 2D array form
    xil_printf("\nResult Matrix C:\n\r");
    Print_Matrix_2D(resultMatrix);

    return 0;
}



// Helper function to write a single word to BRAM
void WriteWordToBRAM(int Offset, int Data, int Bram_index) {
    if (Bram_index == 1)
    {   
        // Set the offset on the address GPIO
        Xil_Out32(XPAR_MICROBLAZE_ADDRESS_BASEADDR, Offset);
        // Set the data on the data GPIO
        Xil_Out32(XPAR_MICROBLAZE_WRITE_DATA_BASEADDR, Data);
    }
    else if (Bram_index == 2)
    {
        // Set the offset on the address GPIO
        Xil_Out32(XPAR_MICROBLAZE_ADDRESS2_BASEADDR, Offset);
        // Set the data on the data GPIO 
        Xil_Out32(XPAR_MICROBLAZE_WRITE_DATA2_BASEADDR, Data);

    }
    else if (Bram_index == 3)
    {
        // Set the offset on the address GPIO
        Xil_Out32(XPAR_MICROBLAZE_ADDRESS3_BASEADDR, Offset);
        // Set the data on the data GPIO
        Xil_Out32(XPAR_MICROBLAZE_WRITE_DATA3_BASEADDR, Data);
    }

    delay(DELAY_VALUE); // Delay

    // Set the write enable (WE) to all 1's (for a 4-bit WE register)
    if (Bram_index == 1) {
        Xil_Out32(XPAR_MICROBLAZE_WRITE_EN_BASEADDR, 0xF);
    } else if (Bram_index == 2) {
        Xil_Out32(XPAR_MICROBLAZE_WRITE_EN2_BASEADDR, 0xF);
    } else if (Bram_index == 3) {
        Xil_Out32(XPAR_MICROBLAZE_WRITE_EN3_BASEADDR, 0xF);
    }
    
    // Wait for write to complete
    delay(DELAY_VALUE); // Extend this delay if needed
    
    // Now reset the write enable (WE) to all 0's
    if (Bram_index == 1) {
        Xil_Out32(XPAR_MICROBLAZE_WRITE_EN_BASEADDR, 0x0);
    } else if (Bram_index == 2) {
        Xil_Out32(XPAR_MICROBLAZE_WRITE_EN2_BASEADDR, 0x0);
    } else if (Bram_index == 3) {
        Xil_Out32(XPAR_MICROBLAZE_WRITE_EN3_BASEADDR, 0x0);
    }

    // Wait after disabling WE before proceeding to the next operation
    delay(DELAY_VALUE);
}

// Main function to initialize a matrix in C²SR format and store it in BRAM
int InitializeMatrixInBRAM(int start_index, u32 matrix[4][4], int rows, int cols, int Bram_index) {
    int data_index = start_index + rows * 8; // Initial index for the non-zero elements data
    int header_index = start_index; // Start index for the row headers (length and pointers)

    // First pass: Write the row headers (row length, row pointer pairs)
    for (int i = 0; i < rows; i++) {
        int row_length = 0;
        for (int j = 0; j < cols; j++) {
            if (matrix[i][j] != 0) {
                row_length++;
            }
        }

        // Write the row length
        WriteWordToBRAM(header_index, row_length, Bram_index);
        header_index += 4;

        delay(DELAY_VALUE); // Delay for write enable stabilization

        // Write the row pointer
        WriteWordToBRAM(header_index, (row_length > 0) ? data_index: 0, Bram_index);
        header_index += 4;

        delay(DELAY_VALUE); // Delay for write enable stabilization

        // Update data_index for the next row's data
        data_index += row_length * 8; // Each non-zero element has a value and a column index
    }
    // Second pass: Write the non-zero elements (value, column index pairs)
    int element_index = start_index + rows * 8; // Start index for non-zero elements
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            if (matrix[i][j] != 0) {
                // Write value
                WriteWordToBRAM(element_index, matrix[i][j], Bram_index);
                element_index += 4;
                delay(DELAY_VALUE); // Delay
                // Write column index
                WriteWordToBRAM(element_index, j, Bram_index);
                element_index += 4;
                delay(DELAY_VALUE); // Delay
            }
        }
    }
    return element_index; // Return the index after the last written element
}


u32 Read_BRAM_Content(int offset, int Bram_index){
    u32 data;
    if (Bram_index == 1)
    {
        Xil_Out32(XPAR_MICROBLAZE_ADDRESS_BASEADDR, offset);
        delay(DELAY_VALUE); // Delay
        data = Xil_In32(XPAR_MICROBLAZE_READ_DATA_BASEADDR);
    }
    else if (Bram_index == 2) {
        Xil_Out32(XPAR_MICROBLAZE_ADDRESS2_BASEADDR, offset);
        delay(DELAY_VALUE); // Delay
        data = Xil_In32(XPAR_MICROBLAZE_READ_DATA2_BASEADDR);
    }
    else if (Bram_index == 3){
        Xil_Out32(XPAR_MICROBLAZE_ADDRESS3_BASEADDR, offset);
        delay(DELAY_VALUE); // Delay
        data = Xil_In32(XPAR_MICROBLAZE_READ_DATA3_BASEADDR);
    }

    return data;
}

int StartMatRaptor(int Matrix_A_start, int Matrix_B_start, int Matrix_C_start, int PE1_Values_loc, int PE2_Values_loc){

    // Reset MatRaptor
    Xil_Out32(XPAR_MICROBLAZE_RESETN_BASEADDR, 1);
    delay(DELAY_VALUE);
    Xil_Out32(XPAR_MICROBLAZE_RESETN_BASEADDR, 0);  

    // Give Matrix Pointers
    Xil_Out32(XPAR_MICROBLAZE_BASEADD_A_BASEADDR, Matrix_A_start);
    Xil_Out32(XPAR_MICROBLAZE_BASEADD_B_BASEADDR, Matrix_B_start);
    Xil_Out32(XPAR_MICROBLAZE_BASEADD_C_BASEADDR, Matrix_C_start);

    // Give Pointer to written PE values
    int PE1_Write_Values_Adderss = PE1_Values_loc;
    int PE2_Write_Values_Adderss = PE2_Values_loc;
    Xil_Out32(XPAR_MICROBLAZE_DATA_WRITE_ADD_PE1_BASEADDR, PE1_Write_Values_Adderss);
    Xil_Out32(XPAR_MICROBLAZE_DATA_WRITE_ADD_PE2_BASEADDR, PE2_Write_Values_Adderss);

    // Give Number of Rows
    Xil_Out32(XPAR_NUMBER_OF_ROWS_BASEADDR, 4);

    // Start MatRaptor
    Xil_Out32(XPAR_MICROBLAZE_START_MULT_BASEADDR, 1);
    delay(DELAY_VALUE);
    Xil_Out32(XPAR_MICROBLAZE_START_MULT_BASEADDR, 0);    

    unsigned int timeout = 100000;
    while (--timeout)
    {
        volatile u32 finished = Xil_In32(XPAR_MATRAPTOR_FINISHED_BASEADDR);
        if (finished != 0)
        {
            xil_printf("\nMatRaptor Finished Successfully!\r\n");   
            return 1;
        }
    }
    xil_printf("Timeout!\n\r");
    return 0;

}

// Implementation of the function
void ReadMatrixFromC2RFormat(u32 C_BaseAddress, int PE1_Values_loc, int PE2_Values_loc,  u32 resultMatrix[4][4]) {
    // Clear the result matrix first
    for (int i = 0; i < 4; ++i) {
        for (int j = 0; j < 4; ++j) {
            resultMatrix[i][j] = 0;
        }
    }
    
    // Read the row headers from BRAM 3
    int rowLength[4];
    int rowPointer[4];
    for (int i = 0; i < 4; ++i) {
        // Assume row headers are stored consecutively
        int offset = i * 8; // 8 bytes for each row header (4 bytes for length, 4 for pointer)
        rowLength[i] = Read_BRAM_Content(C_BaseAddress + offset, 3);
        rowPointer[i] = Read_BRAM_Content(C_BaseAddress + offset + 4, 3);
    }
    
    // Read the values and column indices from BRAM 1 and BRAM 2
    for (int i = 0; i < 4; ++i) {
        // Alternate reading from BRAM 1 and BRAM 2
        int currentBramIndex = (i % 2 == 0) ? 1 : 2;
        int currentValuesBase = (i % 2 == 0) ? PE1_Values_loc : PE2_Values_loc;
        int elementsToRead = rowLength[i];
        int readOffset = rowPointer[i];
        for (int j = 0; j < elementsToRead; ++j) {
            int value = Read_BRAM_Content(currentValuesBase + readOffset, currentBramIndex);
            int colIndex = Read_BRAM_Content(currentValuesBase + readOffset + 4, currentBramIndex);
            resultMatrix[i][colIndex] = value;
            readOffset += 8; // Move to the next value/column index pair
        }
    }
}

void Print_Matrix_2D(u32 matrix[4][4])
{
     for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {
            xil_printf("%d ", matrix[i][j]);
        }
        xil_printf("\n\r");
    }
}


void delay(int number_of_cycles) {
    int i;
    for (i = 0; i < number_of_cycles; i++) {
        asm("nop"); // Assembly instruction for No Operation, to prevent optimization
    }
}